# WordToken


``` pip3 install wordtoken ```

Perform conversational analytics and interface with the WordToken API at https://api.wordtoken.com using this package.